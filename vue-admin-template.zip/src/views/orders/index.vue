<template>
  <div
    class="app-container"
  >
    <!-- <Search
    :search="[
        { title: '客户名称', type: 'input',  },
        { title: '产品名称', type: 'input',  },
        { title: '状态', type: 'input',  },
        { title: '客户名称', type: 'input',  },
        { title: '产品名称', type: 'input',  },
        { title: '状态', type: 'input',  },
        { title: '状态', type: 'input',  },

      ]"
      :button="[{ title: '搜索',type:'' }, { title: '重置',type:'' }, { title: '添加',type:'primary' }]"></Search>
     -->
    <el-drawer
      :with-header="false"
      :visible.sync="drawer"
      direction="rtl"
      :before-close="shutDownDrawer"
      size="70%"
    >
      <div>
        <div class="info">
          <div>订单号：23231233</div>
          <div>金额：12222</div>
          <div>创建时间：22222</div>
          <div>客户名称：2222</div>
          <div>接货仓：3333</div>
          <div>订单状态：完成</div>
          <div>备注</div>
        </div>
        <div class="production">
          <el-tabs  @tab-click="">
            <el-tab-pane label="订单产品" name="first">
              <div style="padding: 0 5px">
        <el-table
          :data="productionsInfo"
          :header-cell-style="{ height: '30px', padding: '0' }"
          v-loading="listLoading"
          element-loading-text="Loading"
          border
          stripe
          highlight-current-row
        >
          <el-table-column label="序号" width="40" align="center">
            <template slot-scope="scope">
              {{ scope.row.id }}
            </template>
          </el-table-column>
          <el-table-column label="名称" width="200" align="center">
            <template slot-scope="scope">
              <span class="threeLine">
                {{ scope.row.name }}
              </span>
            </template>
          </el-table-column>
          <el-table-column label="料号" width="60" align="center">
            <template slot-scope="scope">
              {{ scope.row.num }}
            </template>
          </el-table-column>
          <el-table-column label="单价(个/元)" width="70" align="center">
            <template slot-scope="scope">
              {{ scope.row.price }}
            </template>
          </el-table-column>
          <el-table-column label="总量" width="60" align="center">
            <template slot-scope="scope">
              {{ scope.row.totalPrice }}
            </template>
          </el-table-column>
          <el-table-column label="总价" width="60px" align="center">
            <template slot-scope="scope">
              {{ scope.row.totalPrice }}
            </template>
          </el-table-column>

          <el-table-column label="已出货数量" width="60" align="center">
            <template slot-scope="scope">
              {{ scope.row.totalPrice }}
            </template>
          </el-table-column>
          <el-table-column label="交付日期" width="60" align="center">
            <template slot-scope="scope">
              {{ scope.row.totalPrice }}
            </template>
          </el-table-column>
        </el-table>
      </div>

            </el-tab-pane>
            <el-tab-pane label="发货记录" name="second">

              <div style="padding: 0 5px">
        <el-table
          :data="productionsInfo"
          :header-cell-style="{ height: '30px', padding: '0' }"
          v-loading="listLoading"
          element-loading-text="Loading"
          border
          stripe
          highlight-current-row
        >
          <el-table-column label="序号" width="40" align="center">
            <template slot-scope="scope">
              {{ scope.row.id }}
            </template>
          </el-table-column>
          <el-table-column label="发货单号" width="200" align="center">
            <template slot-scope="scope">
              <span class="threeLine">
                {{ scope.row.name }}
              </span>
            </template>
          </el-table-column>
          <el-table-column label="发货时间" width="60" align="center">
            <template slot-scope="scope">
              {{ scope.row.num }}
            </template>
          </el-table-column>

          <el-table-column label="发货人" width="60" align="center">
            <template slot-scope="scope">
              {{ scope.row.totalPrice }}
            </template>
          </el-table-column>
          <el-table-column label="发货信息" width="60px" align="center">
            <template slot-scope="scope">
              {{ scope.row.totalPrice }}
            </template>
          </el-table-column>
          <el-table-column label="收货方信息" width="60" align="center">
            <template slot-scope="scope">
              {{ scope.row.totalPrice }}
            </template>
          </el-table-column>
          <el-table-column label="物流单号" width="60" align="center">
            <template slot-scope="scope">
              {{ scope.row.totalPrice }}
            </template>
          </el-table-column>
          <el-table-column label="物流费用" width="60" align="center">
            <template slot-scope="scope">
              {{ scope.row.totalPrice }}
            </template>
          </el-table-column>
          <el-table-column label="备注" width="60" align="center">
            <template slot-scope="scope">
              {{ scope.row.totalPrice }}
            </template>
          </el-table-column>
        </el-table>
      </div>
            </el-tab-pane>
            
          </el-tabs>
        </div>
      </div>
      
     
    </el-drawer>
    <!-- 添加弹窗 -->
    <el-dialog
      title="添加订单"
      :visible.sync="visibleDialog"
      :before-close="closeDialog"
    >
      <el-form
        :rules="rules"
        class="add"
        :model="ordersInfo"
        style="display: flex; flex-wrap: wrap; justify-content: space-between"
      >
        <el-form-item label="公司名称" style="width: 48%" prop="companyName">
          <el-input v-model="ordersInfo.companyName"></el-input>
        </el-form-item>
        <el-form-item label="公司地址" style="width: 48%" prop="adress">
          <el-input v-model="ordersInfo.adress"></el-input>
        </el-form-item>
        <el-form-item label="银行账号" style="width: 48%">
          <el-input v-model="ordersInfo.bankAccount"></el-input>
        </el-form-item>
        <el-form-item class="production" label="产品信息" style="width: 48%">
          <el-select
            v-model="ordersInfo.productions"
            multiple
            filterable
            placeholder="请选择"
            @change="addProductionInfo"
          >
            <el-option
              v-for="(item, index) in productionList"
              :key="index"
              :label="item.name"
              :value="item.id"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="姓名" style="flex: 1">
          <el-input v-model="ordersInfo.name"></el-input>
        </el-form-item>
        <el-form-item
          label="手机号"
          style="flex: 2; margin-left: 5px; margin-right: 5px"
        >
          <el-input v-model="ordersInfo.phone"></el-input>
        </el-form-item>
        <el-form-item label="电子邮件" style="flex: 2">
          <el-input v-model="ordersInfo.email"></el-input>
        </el-form-item>
        <!-- 产品详情 -->
        <div
          style="
            width: 100%;
            border-top: 1px solid red;
            padding-top: 5px;
            margin-top: 5px;
          "
          label-position="left"
          v-for="(item, index) in ordersInfo.productions"
          :key="index"
        >
          <div style="text-align: center; font-weight: 700; font-size: 20px">
            {{ productionList[item].abbr }}
          </div>
          <el-form-item label="产品名称:">
            <span>{{ productionList[item].name }}</span>
          </el-form-item>
          <div style="display: flex; margin: 10px 0 20px 0">
            <el-form-item
              label="数量(个):"
              label-width="80px"
              style="flex: 2; margin-left: -12px"
            >
              <el-input
                v-model="ordersInfo.productionInfo[index].number"
              ></el-input>
            </el-form-item>
            <el-form-item
              label="单价(元):"
              label-width="80px"
              style="flex: 2; margin: 0 20px"
            >
              <el-input
                v-model="ordersInfo.productionInfo[index].price"
              ></el-input>
            </el-form-item>
            <el-form-item label="总价(元):" label-width="80px" style="flex: 2">
              <!-- <span>{{ ordersInfo.productionInfo[index].totalPrice }}</span> -->
              <span>{{
                ordersInfo.productionInfo[index].price *
                ordersInfo.productionInfo[index].number
              }}</span>
            </el-form-item>
          </div>
          <el-form-item
            label="客户料号"
            label-width="100px;"
            style="display: flex"
          >
            <el-input
              v-model="ordersInfo.productionInfo[index].materialNum"
            ></el-input>
          </el-form-item>
          <el-form-item label="客户料号描述">
            <el-input
              v-model="ordersInfo.productionInfo[index].materialDescription"
            ></el-input>
          </el-form-item>
        </div>
      </el-form>
      <div slot="footer">
        <el-button @click="cancel">取消</el-button>
        <el-button type="primary" @click="sendOrderInfo">确定</el-button>
      </div>
    </el-dialog>
    <!--  -->
    <el-table
      v-loading="listLoading"
      :data="list"
      element-loading-text="Loading"
      border
      stripe
      highlight-current-row
    >
      <el-table-column align="center" label="序号" min-width="50">
        <template slot-scope="scope">
          <!-- {{ scope.$index }} -->
          100
        </template>
      </el-table-column>
      <el-table-column label="客户名称" align="center" min-width="140">
        <template slot-scope="scope">
          深圳市艾联特电子科技有限公司
        </template>
      </el-table-column>
      <el-table-column align="center" label="订单号" min-width="180">
        <template slot-scope="scope">
          QG-E-RES-0010-iNNO-1
        </template>
      </el-table-column>
      <el-table-column align="center" label="客户料号" min-width="140">
        <template slot-scope="scope">
          <el-popover
            placement="top-start"
            min-width="200%"
            trigger="hover"
            content="aaaaaaaaaaaaaaaaa深圳市南山区西丽街道西丽社区打石一路万科云城四期(集中 商业项目) B 1002"
          >
          <span class="threeLine" slot="reference">
          PCBA-全格-蓝牙版-UVC-杀菌灯板
          </span>
          </el-popover>
        </template>
      </el-table-column>
      <el-table-column align="center" label="产品料号" min-width="140">
        <template slot-scope="scope">
          <el-popover
            placement="top-start"
            min-width="200%"
            trigger="hover"
            content="aaaaaaaaaaaaaaaaa深圳市南山区西丽街道西丽社区打石一路万科云城四期(集中 商业项目) B 1002"
          >
          <span class="threeLine" slot="reference">
          PCBA-全格-蓝牙版-UVC-杀菌灯板
          </span>
          </el-popover>
        </template>
      </el-table-column>
      <el-table-column align="center" label="产品名称" min-width="140">
        <template slot-scope="scope">
          <el-popover
            placement="top-start"
            min-width="200%"
            trigger="hover"
            content="aaaaaaaaaaaaaaaaa深圳市南山区西丽街道西丽社区打石一路万科云城四期(集中 商业项目) B 1002"
          >
          <span class="threeLine" slot="reference">
          PCBA-全格-蓝牙版-UVC-杀菌灯板
          </span>
          </el-popover>
        </template>
      </el-table-column>
      <el-table-column align="center" label="产品总数" min-width="80">
        <template slot-scope="scope">
          1000000
        </template>
      </el-table-column>
      <el-table-column align="center" label="出库数" min-width="80">
        <template slot-scope="scope">
          300
        </template>
      </el-table-column>
      <el-table-column align="center" label="未出库数" min-width="80">
        <template slot-scope="scope">
          700
        </template>
      </el-table-column>
      <el-table-column align="center" label="订单总价" min-width="100">
        <template slot-scope="scope">
          10000
        </template>
      </el-table-column>
      <el-table-column label="订单状态"  align="center" min-width="80">
        <template slot-scope="scope">
          完成
        </template>
      </el-table-column>
      <el-table-column
        align="center"
        prop="created_at"
        label="下单时间"
        width="180"
      >
        <template slot-scope="scope">
          <i class="el-icon-time" />
          <span>{{ scope.row.display_time }}</span>
        </template>
      </el-table-column>
      <el-table-column
        align="center"
        label="操作"
        min-width="200"
        fixed="right"
      >
        <template slot-scope="scope">
          <el-button
            type="primary"
            size="small"
            @click="showDrawer(scope.row.id)"
            >产品信息</el-button
          >
          <el-button type="danger">取消订单</el-button>
          <el-button type="primary" size="small" @click="editDialog(scope.row)"
            >编辑</el-button
          >
          <el-button type="danger" size="small" @click="deleteClient(scope.row)"
            >删除</el-button
          >
          <el-button type="primary" size="small">隐藏</el-button>
          <el-button type="info" size="small"></el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import { getList } from "@/api/table";
import Search from "@/components/Search/index.vue";
import throttle from "lodash/throttle";

export default {
  components: {
    Search,
  },
  filters: {
    statusFilter(status) {
      const statusMap = {
        published: "success",
        draft: "gray",
        deleted: "danger",
      };
      return statusMap[status];
    },
  },
  data() {
    const validAllChinese = (rule, value, callback) => {
      if (/^[\u4e00-\u9fa5]{1,}$/.test(value) == false) {
        callback(new Error("请输入正确的公司名"));
      } else {
        callback();
      }
    };
    const validAdress = (rule, value, callback) => {
      if (!/.+?(省|市|自治区|自治州|县|区)/g.test(value)) {
        callback(new Error("请输入正确的地址"));
      } else {
        callback();
      }
    };
    return {
      list: [{ id: 0 }],
      listLoading: false,
      //产品信息抽屉
      drawer: false,
      //添加订单弹窗
      visibleDialog: false,
      //
      visibleDialogEdit: false,
      //抽屉显示产品信息
      productionsInfo: [
        {
          id: 1,
          name: "产品aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaafdfsfd",
          num: 13,
          price: 10,
          totalPrice: 130,
        },
        {
          id: 1,
          name: "产品a",
          num: 13,
          price: 10,
          totalPrice: 130,
        },
      ],
      //收集发送后台//编辑
      ordersInfo: {
        companyName: "aaa",
        companyAdress: "444",
        adress: "什么路",
        bankAccount: "41231",
        name: "333",
        phone: "222",
        email: "111",
        productions: [0],
        productionInfo: [
          {
            productionID: 0,
            number: 10,
            price: 13,
            totalPrice: null,
            materialNum: "12",
            materialDescription: "123a",
          },
        ],
      },
      //添加时用selecct后端拿
      productionList: {
        0: {
          id: 0,
          name: "产品aaaaaaaaaaaaaaaaaaaaa",
          abbr: "产品a",
        },
        1: {
          id: 1,
          name: "产品bbbbbbbbbbbbbbbbbbbb",
          abbr: "产品b",
        },
        2: {
          id: 2,
          name: "产品cccccccccccccccccccc",
          abbr: "产品c",
        },
      },
      //抽屉里用/后端拿
      customerProductionMaterialNum: [
        {
          name: "abc",
          number: "123",
        },
        {
          name: "def",
          number: "456",
        },
        {
          name: "ghi",
          number: "789",
        },
        {
          name: "jkl",
          number: "101112",
        },
      ],
      rules: {
        companyName: [
          { required: true, message: "请填写公司名", trigger: "blur" },
          { validator: validAllChinese, trigger: "blur" },
        ],
        companyAdress: [
          { required: true, message: "请填写公司地址", trigger: "blur" },
          { validator: validAdress, trigger: "blur" },
        ],
      },
    };
  },
  created() {
    this.fetchData();
  },
  mounted() {
    this.$bus.$on("add", this.dialog);
  },
  beforeDestroy() {
    this.$bus.$off();
  },
  methods: {
    //取消
    cancel() {
      this.ordersInfo = {
        companyName: "",
        companyAdress: "",
        name: "",
        phone: "",
        email: "",
        productions: [],
        productionInfo: [],
      };
      this.visibleDialog = false;
    },
   
    //初始化
    fetchData() {
      // this.listLoading = true;
      // getList().then((response) => {
      //   this.list = response.data.items;
      //   this.listLoading = false;
      // });
    },
    
  },
};
</script>
<style lang="scss">
// // 
// //三行显示，超过为省略
// .threeLine {
//   overflow: hidden;
//   text-overflow: ellipsis;
//   display: -webkit-box;
//   -webkit-line-clamp: 3;
//   -webkit-box-orient: vertical;
// }

// .production {
//   .el-select {
//     width: 100%;
//   }
// }
// .app-container,
// .drawer {
//   overflow: auto;
//   padding-top: 0;
//   width: 100%;
//   display: flex;
//   flex-direction: column;
//   justify-content: space-between;
// }
// .drawer {
//   overflow: auto;
//   padding-top: 0;
//   width: 100%;
//   position: absolute;
//   display: flex;
//   flex-direction: column;
//   justify-content: space-between;
//   height: 100%;
// }
</style>
