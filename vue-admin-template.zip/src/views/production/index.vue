<template>
  <div class="app-container production" v-loading.lock="FlistLoading">
    <Search
      :search="[
        { title: '客户名称', type: 'input' },
        { title: '客户料号', type: 'input' },
        { title: '产品料号', type: 'input' },
        { title: '产品名称', type: 'input' },
        { title: '产品规格', type: 'input' },
        { title: '描述', type: 'input' },
        { title: '备注', type: 'input' },
      ]"
      :button="[
        { title: '搜索', type: '' },
        { title: '重置', type: '' },
        { title: '添加', type: 'primary' },
      ]"
    ></Search>
    <el-pagination
      style="margin-bottom: 10px"
      background
      layout="sizes,prev, pager, next"
      :total="page_total"
      @current-change="pageChange"
      @size-change="sizeChange"
      :current-page="page_current"
      :page-size="page_size"
      :page-sizes="[10, 50, 100]"
    >
    </el-pagination>
    <!-- 添加 -->
    <el-drawer
      class="addProductionDrawer"
      direction="rtl"
      size="35%"
      title="添加产品"
      :visible.sync="visibleDialog"
      @close="closeAddDrawer"
    >
    <div>
      <el-form
        :model="productionInfo"
        label-width="100px"
        :rules="rulesProduction"
        ref="productionForm"
      >
        <el-form-item label="客户名称" prop="companyName">
          <el-autocomplete
            class="inline-input"
            v-model="productionInfo.companyName"
            :fetch-suggestions="querySearch"
            placeholder="请输入内容"
            :trigger-on-focus="false"
            @select="handleSelect"
          ></el-autocomplete>
        </el-form-item>
        <el-form-item label="客户料号" prop="companyMNumber">
          <el-input v-model="productionInfo.companyMNumber"></el-input>
        </el-form-item>
        <el-form-item label="产品料号" prop="productionMNumber">
          <el-input v-model="productionInfo.productionMNumber"></el-input>
        </el-form-item>
        <el-form-item label="产品名称" prop="productionName">
          <el-input v-model="productionInfo.productionName"></el-input>
        </el-form-item>
        <el-form-item label="产品规格" prop="specification">
          <el-input v-model="productionInfo.specification"></el-input>
        </el-form-item>
        <el-form-item label="描述" prop="description">
          <el-input
            v-model="productionInfo.description"
            prop="description"
          ></el-input>
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model="productionInfo.remarks"></el-input>
        </el-form-item>
      </el-form>
    </div>
      <div
        style="
          height: 140px;
          display: flex;
          justify-content: space-between;
          margin: 0 30px;
          background-color: rgba(128, 128, 128, 0.1);
          border-radius: 5px;
          margin: 10px;
          padding: 10px 20px;
        "
      >
        <div style="font-size:30px;">产品BOM信息</div>
        <div style="width:190px;">
          <el-upload
            style="display: flex;flex-direction:row-reverse;flex-wrap: wrap;"
            class="upload-demo"
            
            :before-remove="beforeRemove"
            :limit="1"
            :file-list="bomInfo.fileList"
            :auto-upload="false"
            ref="upload"
            :on-success="showList"
            
          >
            <!-- <el-button size="small" type="primary">上传BOM</el-button> -->
            
              <el-button slot="trigger" size="small" type="primary" style="height:100%;"
                >选取BOM文件</el-button
              >
              <el-button
                style="margin-left: 10px;margin-right: 10px;"
                size="small"
                type="success"
                @click="submitUpload"
                >上传</el-button
              >
            
            <div slot="tip" class="el-upload__tip">请上传EXEL表格，会覆盖已有表格</div>
          </el-upload>
        </div>
      </div>
      <div style="float: right; margin-right: 30px; margin-bottom: 20px">
        <el-button @click="cancel">取消</el-button>
        <el-button type="primary" @click="Determine">确定</el-button>
      </div>
      <div v-if="bomList.length" style="margin: 10px">
        <el-table
          v-loading="listLoading"
          element-loading-text="Loading"
          border
          stripe
          highlight-current-row
          :data="bomList"
          :row-style="{ height: '100px' }"
          :header-cell-style="{ height: '40px' }"
        >
          <el-table-column
            align="center"
            label="项次"
            width="50"
            class-name="li"
          >
            <template slot-scope="scope">
              <!-- {{ scope.$index + 1 }} -->
              999
            </template>
          </el-table-column>
          <el-table-column
            label="料号"
            align="center"
            width="140"
            class-name="li"
          >
            <template slot-scope="scope">
              <span
                class="threeLine"
                slot="reference"
                style="
                  display: flex;
                  justify-content: start;
                  text-align: start !important;
                "
              >
                IE-10-131-001-A
              </span>
            </template>
          </el-table-column>
          <el-table-column
            label="品名"
            align="center"
            min-width="140"
            class-name="li"
          >
            <template slot-scope="scope">
              <el-popover
                placement="top-start"
                min-width="200%"
                trigger="hover"
                content="scope.row.address"
              >
                <span
                  class="threeLine"
                  slot="reference"
                  style="
                    display: flex;
                    justify-content: start;
                    text-align: start !important;
                  "
                >
                  UVA-UVC-杀菌灯-铝基板-PCB
                </span>
              </el-popover>
            </template>
          </el-table-column>
          <el-table-column
            label="规格"
            align="center"
            min-width="140"
            class-name="li"
          >
            <template slot-scope="scope">
              <el-popover
                placement="top-start"
                min-width="200%"
                trigger="hover"
                content="scope.row.address"
              >
                <span
                  class="threeLine"
                  slot="reference"
                  style="
                    display: flex;
                    justify-content: start;
                    text-align: start !important;
                  "
                >
                  UVA-UVC-杀菌灯
                  260-280nm-395-405nm-3.5x3.5x1.41mm-3-6W-5-7V-3.0-3.4V-40-100mA
                </span>
              </el-popover>
            </template>
          </el-table-column>
          <el-table-column
            label="用量"
            align="center"
            width="50"
            class-name="li"
          >
            <template slot-scope="scope"> 100 </template>
          </el-table-column>
          <el-table-column
            label="位置号"
            align="center"
            width="140"
            class-name="li"
          >
            <template slot-scope="scope">
              <el-popover
                placement="top-start"
                min-width="200%"
                trigger="hover"
                content="scope.row.address"
              >
                <span
                  class="threeLine"
                  slot="reference"
                  style="
                    display: flex;
                    justify-content: start;
                    text-align: start !important;
                  "
                >
                  UVA-UVC-杀菌灯
                </span>
              </el-popover>
            </template>
          </el-table-column>
          <el-table-column
            label="供应商"
            align="center"
            width="140"
            class-name="li"
          >
            <template slot-scope="scope">
              <el-popover
                placement="top-start"
                min-width="200%"
                trigger="hover"
                content="scope.row.address"
              >
                <span
                  class="threeLine"
                  slot="reference"
                  style="
                    display: flex;
                    justify-content: start;
                    text-align: start !important;
                  "
                >
                  浙江锦顺
                </span>
              </el-popover>
            </template>
          </el-table-column>
          <el-table-column
            label="供应商料号"
            align="center"
            width="140"
            class-name="li"
          >
            <template slot-scope="scope">
              <span
                class="threeLine"
                slot="reference"
                style="
                  display: flex;
                  justify-content: start;
                  text-align: start !important;
                "
              >
                IE-10-131-001-A
              </span>
            </template>
          </el-table-column>
          <el-table-column
            label="备注"
            align="center"
            width="180"
            class-name="li"
          >
            <template slot-scope="scope">
              <el-popover
                placement="top-start"
                min-width="200%"
                trigger="hover"
                content="scope.row.address"
              >
                <span
                  class="threeLine"
                  slot="reference"
                  style="
                    display: flex;
                    justify-content: start;
                    text-align: start !important;
                  "
                >
                  {{ scope.row.id }}
                </span>
              </el-popover>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </el-drawer>
    <!-- 查看 -->
    <el-drawer
      class="addProductionDrawer"
      direction="rtl"
      size="35%"
      title="产品信息"
      :visible.sync="visibleDialog_info"
      @close="closeInfo"
    >
      <div style="display: flex; flex-wrap: wrap" class="info">
        <div>
          <div>客户名称</div>
          <div>惠州市奕麟科技技术有限公司我是是是搜索啊</div>
        </div>
        <div>
          <div>客户料号</div>
          <div>PCBA-全格-蓝牙版-UVC-杀菌灯板</div>
        </div>
        <div>
          <div>产品料号</div>
          <div>PCBA-全格-蓝牙版-UVC-杀菌灯板</div>
        </div>
        <div>
          <div>产品名称</div>
          <div>PCBA-全格-蓝牙版-UVC-杀菌灯板</div>
        </div>
        <div>
          <div>产品规格</div>
          <div>
            UVA-UVC-杀菌灯260-280nm-395-405nm-3.5x3.5x1.41mm-3-6W-5-7V-3.0-3.4V-40
          </div>
        </div>
        <div>
          <div>描述</div>
          <div>PCBA-全格-蓝牙版-UVC-杀菌灯板 长：56.59*宽36.9*高12.18MM</div>
        </div>
        <div>
          <div>备注</div>
          <div>这里应上的方法的范德萨发的范德萨发生房</div>
        </div>
      </div>
      <div
        style="
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin: 0 30px;
          background-color: rgba(128, 128, 128, 0.2);
          border-radius: 5px;
          margin: 10px;
          padding: 10px 20px;
        "
      >
        <div>产品BOM信息</div>
        <div>
          <el-button size="small" type="primary">下载BOM表格</el-button>
        </div>
      </div>
      <div style="margin: 10px">
        <el-table
          v-loading="listLoading"
          element-loading-text="Loading"
          border
          stripe
          highlight-current-row
          :data="bomList"
          :row-style="{ height: '100px' }"
          :header-cell-style="{ height: '40px' }"
        >
          <el-table-column
            align="center"
            label="序号"
            width="50"
            class-name="li"
          >
            <template slot-scope="scope">
              <!-- {{ scope.$index + 1 }} -->
              999
            </template>
          </el-table-column>
          <el-table-column
            label="料号"
            align="center"
            width="140"
            class-name="li"
          >
            <template slot-scope="scope">
              <span
                class="threeLine"
                slot="reference"
                style="
                  display: flex;
                  justify-content: start;
                  text-align: start !important;
                "
              >
                IE-10-131-001-A
              </span>
            </template>
          </el-table-column>
          <el-table-column
            label="物料名称"
            align="center"
            min-width="140"
            class-name="li"
          >
            <template slot-scope="scope">
              <el-popover
                placement="top-start"
                min-width="200%"
                trigger="hover"
                content="scope.row.address"
              >
                <span
                  class="threeLine"
                  slot="reference"
                  style="
                    display: flex;
                    justify-content: start;
                    text-align: start !important;
                  "
                >
                  UVA-UVC-杀菌灯-铝基板-PCB
                </span>
              </el-popover>
            </template>
          </el-table-column>
          <el-table-column
            label="规格"
            align="center"
            min-width="140"
            class-name="li"
          >
            <template slot-scope="scope">
              <el-popover
                placement="top-start"
                min-width="200%"
                trigger="hover"
                content="scope.row.address"
              >
                <span
                  class="threeLine"
                  slot="reference"
                  style="
                    display: flex;
                    justify-content: start;
                    text-align: start !important;
                  "
                >
                  UVA-UVC-杀菌灯
                  260-280nm-395-405nm-3.5x3.5x1.41mm-3-6W-5-7V-3.0-3.4V-40-100mA
                </span>
              </el-popover>
            </template>
          </el-table-column>
          <el-table-column
            label="用量"
            align="center"
            width="50"
            class-name="li"
          >
            <template slot-scope="scope"> 100 </template>
          </el-table-column>
          <el-table-column
            label="位置号"
            align="center"
            width="140"
            class-name="li"
          >
            <template slot-scope="scope">
              <el-popover
                placement="top-start"
                min-width="200%"
                trigger="hover"
                content="scope.row.address"
              >
                <span
                  class="threeLine"
                  slot="reference"
                  style="
                    display: flex;
                    justify-content: start;
                    text-align: start !important;
                  "
                >
                  UVA-UVC-杀菌灯
                </span>
              </el-popover>
            </template>
          </el-table-column>
          <el-table-column
            label="供应商"
            align="center"
            width="140"
            class-name="li"
          >
            <template slot-scope="scope">
              <el-popover
                placement="top-start"
                min-width="200%"
                trigger="hover"
                content="scope.row.address"
              >
                <span
                  class="threeLine"
                  slot="reference"
                  style="
                    display: flex;
                    justify-content: start;
                    text-align: start !important;
                  "
                >
                  浙江锦顺
                </span>
              </el-popover>
            </template>
          </el-table-column>
          <el-table-column
            label="供应商料号"
            align="center"
            width="140"
            class-name="li"
          >
            <template slot-scope="scope">
              <span
                class="threeLine"
                slot="reference"
                style="
                  display: flex;
                  justify-content: start;
                  text-align: start !important;
                "
              >
                IE-10-131-001-A
              </span>
            </template>
          </el-table-column>
          <el-table-column
            label="备注"
            align="center"
            width="180"
            class-name="li"
          >
            <template slot-scope="scope">
              <el-popover
                placement="top-start"
                min-width="200%"
                trigger="hover"
                content="scope.row.address"
              >
                <span
                  class="threeLine"
                  slot="reference"
                  style="
                    display: flex;
                    justify-content: start;
                    text-align: start !important;
                  "
                >
                  {{ scope.row.id }}
                </span>
              </el-popover>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div id="tabbar"></div>
    </el-drawer>
    <!--  -->
    <!-- <el-drawer
      :with-header="false"
      :visible.sync="drawer"
      direction="rtl"
      :before-close="shutDownDrawer"
      size="60%"
    >
      <div>
        <div class="info">
          <div>产品名称：333</div>
          <div>料号：dfdf</div>
          <div>品牌商：dfdf</div>
          <div>备注：</div>
        </div>

        <div style="padding: 0 5px">
          产品BOM信息
          <el-table
            :data="productionsInfo"
            :header-cell-style="{ height: '30px', padding: '0' }"
            v-loading="listLoading"
            element-loading-text="Loading"
            border
            stripe
            highlight-current-row
          >
            <el-table-column label="序号" width="40" align="center">
              <template slot-scope="scope">
                {{ scope.row.id }}
              </template>
            </el-table-column>

            <el-table-column label="原件料号" width="200" align="center">
              <template slot-scope="scope">
                <span class="threeLine">
                  {{ scope.row.name }}
                </span>
              </template>
            </el-table-column>
            <el-table-column label="原件名称" width="200" align="center">
              <template slot-scope="scope">
                <span class="threeLine">
                  {{ scope.row.name }}
                </span>
              </template>
            </el-table-column>

            <el-table-column label="用量" width="60" align="center">
              <template slot-scope="scope">
                {{ scope.row.num }}
              </template>
            </el-table-column>
            <el-table-column label="规格" width="70" align="center">
              <template slot-scope="scope">
                {{ scope.row.price }}
              </template>
            </el-table-column>

            <el-table-column label="厂商" width="60" align="center">
              <template slot-scope="scope">
                {{ scope.row.totalPrice }}
              </template>
            </el-table-column>
            <el-table-column label="位置号" width="60" align="center">
              <template slot-scope="scope">
                {{ scope.row.totalPrice }}
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
    </el-drawer> -->
    <div>
      <el-table
        v-loading="listLoading"
        :data="list"
        element-loading-text="Loading"
        border
        stripe
        fit
        highlight-current-row
        :row-style="{ height: '127px' }"
        :header-cell-style="{ left: 0, right: 0 }"
        @sort-change="sort"
      >
        <el-table-column align="center" label="序号" width="50" class-name="li">
          <template slot-scope="scope">
            {{ scope.$index + 1 }}
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="客户名称"
          min-width="250"
          class-name="li"
        >
          <template slot-scope="scope">
            <span
              slot="reference"
              style="
                display: flex;
                justify-content: start;
                text-align: start !important;
              "
            >
              惠州市奕麟科技技术有限公司我是是是搜索啊
            </span>
          </template>
        </el-table-column>
        <el-table-column
          label="客户料号"
          min-width="200"
          align="center"
          class-name="li"
        >
          <template slot-scope="scope">
            <span
              slot="reference"
              style="
                display: flex;
                justify-content: start;
                text-align: start !important;
              "
            >
              PCBA-全格-蓝牙版-UVC-杀菌灯板
            </span>
          </template>
        </el-table-column>
        <el-table-column
          label="产品料号"
          min-width="200"
          align="center"
          class-name="li"
        >
          <template slot-scope="scope">
            <span
              slot="reference"
              style="
                display: flex;
                justify-content: start;
                text-align: start !important;
              "
            >
              PCBA-全格-蓝牙版-UVC-杀菌灯板
            </span>
          </template>
        </el-table-column>
        <el-table-column
          label="产品名称"
          min-width="200"
          align="center"
          class-name="li"
        >
          <template slot-scope="scope">
            <span
              style="
                display: flex;
                justify-content: start;
                text-align: start !important;
              "
            >
              PCBA-全格-蓝牙版-UVC-杀菌灯板
            </span>
          </template>
        </el-table-column>
        <el-table-column
          label="产品规格"
          min-width="200"
          align="center"
          class-name="li"
        >
          <template slot-scope="scope">
            <span
              style="
                display: flex;
                justify-content: start;
                text-align: start !important;
              "
            >
              UVA-UVC-杀菌灯260-280nm-395-405nm-3.5x3.5x1.41mm-3-6W-5-7V-3.0-3.4V-40-100mA
            </span>
          </template>
        </el-table-column>
        <el-table-column
          label="描述"
          width="200"
          align="center"
          class-name="li"
        >
          <template slot-scope="scope">
            <el-popover
              placement="top-start"
              min-width="200%"
              trigger="hover"
              content="aaaaaaaaaaaaaa"
            >
              <span
                class="threeLine"
                slot="reference"
                style="
                  display: flex;
                  justify-content: start;
                  text-align: start !important;
                "
              >
                PCBA-全格-蓝牙版-UVC-杀菌灯板 长：56.59*宽36.9*高12.18MM
              </span>
            </el-popover>
          </template>
        </el-table-column>
        <el-table-column
          label="备注"
          min-width="110"
          align="center"
          class-name="li"
        >
          <template slot-scope="scope">
            <el-popover
              placement="top-start"
              min-width="200%"
              trigger="hover"
              content="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaassssssssssssssssssssssssaaaaaaaaaaaaaaa"
            >
              <span
                class="threeLine"
                slot="reference"
                style="
                  display: flex;
                  justify-content: start;
                  text-align: start !important;
                "
              >
                这里应上的方法的范德萨发的范德萨发生房
              </span>
            </el-popover>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          prop="created_at"
          label="创建时间"
          width="170"
          class-name="li"
          sortable="custom"
        >
          <template slot-scope="scope">
            <i class="el-icon-time" />
            <span>2022-11-10 12:12:12</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="操作"
          width="200"
          fixed="right"
          class-name="button"
        >
          <template slot-scope="scope" style="display: flex; flex-wrap: wrap">
            <el-button type="primary" size="small" @click="showInfo"
              >产品信息</el-button
            >
            <el-button type="primary" size="small" @click="editProduction"
              >编辑</el-button
            >
            <el-button type="info" size="small"></el-button>
            <el-popconfirm
              title="确定删除吗？"
              icon="el-icon-info"
              icon-color="red"
            >
              <el-button type="danger" size="small" slot="reference">
                删除
              </el-button>
            </el-popconfirm>
            <el-button type="info" size="small"></el-button>
            <el-button type="info" size="small"></el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="footer">
      <el-pagination
        background
        layout="sizes,prev, pager, next"
        :total="page_total"
        @current-change="pageChange"
        @size-change="sizeChange"
        :current-page="page_current"
        :page-size="page_size"
        :page-sizes="[10, 50, 100]"
      >
      </el-pagination>
    </div>
  </div>
</template>

<script>
import { getList, getCompanyList,addProduction,getBOMList } from "@/api/table";
import Search from "@/components/Search/index.vue";
import throttle from "lodash/throttle";
// let XLSX = require('xlsx');
import * as XLSX from 'xlsx/xlsx.mjs';
import * as fs from 'fs';
import { Readable } from 'stream';
XLSX.stream.set_readable(Readable);
import * as cpexcel from 'xlsx/dist/cpexcel.full.mjs';
XLSX.set_cptable(cpexcel);

export default {
  components: {
    Search,
  },
  filters: {
    statusFilter(status) {
      const statusMap = {
        published: "success",
        draft: "gray",
        deleted: "danger",
      };
      return statusMap[status];
    },
  },
  data() {
    return {
      list: [{ id: 1 },{id:3}],
      bomList: [{ id: 1 }],
      listLoading: false,
      FlistLoading: false,
      //
      page_size: 10,
      page_current: 1,
      page_total: 1000,
      //
      order: "desc",
      id:null,
      //
      visibleDialog: false,
      visibleDialog_info: false,
      isEdit:false,
      //
      productionInfo: {
        companyName: "",
        companyMNumber: "",
        productionMNumber: "",
        productionName: "",
        specification: "",
        description: "",
        remarks: "",
      },
      bomInfo: {
        fileList: [
          {
            name: "food.jpeg",
            url: "https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100",
          },
        ],
      },
      rulesProduction: {
        companyName: [{ required: true, message: "请输入", trigger: "blur" }],
        companyMNumber: [
          { required: true, message: "请输入", trigger: "blur" },
        ],
        productionMNumber: [
          { required: true, message: "请输入", trigger: "blur" },
        ],
        productionName: [
          { required: true, message: "请输入", trigger: "blur" },
        ],
        specification: [{ required: true, message: "请输入", trigger: "blur" }],
        description: [{ required: true, message: "请输入", trigger: "blur" }],
      },
    };
  },
  created() {
    this.fetchData();
    // this.FlistLoading = true;
  },
  mounted() {
    this.$bus.$on("add", this.addProduction);
    this.$bus.$on("goSearch", this.search);
  },
  beforeDestroy() {
    this.$bus.$off();
  },
  methods: {
    async slsx(){
      const file = document.querySelector('.el-upload__input');
      const target = document.querySelector('#tabbar');
      const data =await file.files[0].arrayBuffer();
      const wb = XLSX.read(data);
      const ws = wb.Sheets[wb.SheetNames[0]];
      console.log(XLSX.utils.sheet_to_json(ws));
    },
    //上传成功后获取列表信息显示
    showList(){

    },
    //上传时添加
    submitUpload() {
      this.slsx();
      // const file = document.querySelector('.el-upload__input');
      // const target = file.files[0];

      // this.$refs.productionForm.validate((valid)=>{
      //   if(valid){
      //     this.FlistLoading = true;
      //     addProduction(this.productionInfo).then((res)=>{
      //       console.log(res);
      //       // this.id=res.data.product_id;
      //       // this.$refs.upload.submit();
      //       // getBOMList({id:this.id,}).then((res)=>{
      //       //   this.bomList = res.data.list;
      //       //   this.FlistLoading = false;
      //       // })
      //     });
      //   }
      // })
    },
    //客户信息选择
    querySearch(value, cb) {
      // cb([{value:''}])
      getCompanyList(value).then((res) => {
        cb(
          res.data.res.length == 0
            ? [{ value: "不存在相关客户" }]
            : res.data.res
        );
      });
    },
    //选中客户名字
    handleSelect(select) {
      this.productionInfo.companyName = select.id;
    },
    //文件上传后删除
    beforeRemove(file, fileList) {
      return this.$confirm(`确定移除 ${file.name}？`);
    },
    search(search) {

    },
    //打开添加抽屉
    addProduction() {
      this.addOpenDrawer();
    },
    //切换页面
    pageChange(current) {
      this.page_current = current;
    },
    sizeChange(size) {
      this.page_size = size;
    },
    //时间排序
    sort(column) {
      this.order = column.order == "descending" ? "desc" : "asc";
      this.fetchData();
    },
    //添加抽屉的开关
    addOpenDrawer() {
      this.visibleDialog = true;
    },
    closeAddDrawer() {
      this.visibleDialog = false;
      this.isEdit=false;
      this.fetchData();
    },
    //产品详情的drawer的开关
    showInfo() {
      this.visibleDialog_info = true;
    },
    closeInfo() {
      this.visibleDialog_info = false;
    },
    editProduction() {
      this.addOpenDrawer();
    },
    //
    fetchData() {
      // this.listLoading = true;
      // // ----------------------------------------------
      // getList().then((response) => {
      //   this.list = response.data.items;
      //   this.listLoading = false;
      // });
      // getProductionList().then((res)=>{
      //   this.list = res.data;
      //   this.FlistLoading =false;
      // });
    },
    //添加后取消-》删除
    cancel(){

    },
    //添加后确定
    Determine(){
      this.closeAddDrawer();
    }
  },
};
</script>
<style lang="scss">
.el-drawer__wrapper {
  .el-drawer__body {
    height: 100px;
  }
}
.el-drawer .rtl {
  height: 90% !important;
  .el-drawer__body {
    height: 100%;
  }
}
.production {
  .info {
    margin: 10px;
    justify-content: space-between;
    background-color: rgba(230, 230, 230, 0.4);
    border-radius: 10px;
    padding: 20px;
    & > div {
      // border:1px solid black;
      height: 100px;
      width: 30%;
      // background-color: pink;
      div:first-child {
        font-weight: 700;
        height: 30px;
        line-height: 30px;
        color: #909399;
        // background-color: yellow;
      }
    }
  }
  .addProductionDrawer {
    .el-drawer {
      min-width: 1230px !important;
      overflow: auto !important;
      height: 100%;
      display: flex;
      justify-content: center;
      .el-form {
        display: flex;
        flex-wrap: wrap;
        .el-form-item {
          display: flex;
          justify-content: center;
          .el-form-item__content {
            margin: 0 !important;
            .el-input {
              width: 300px;
            }
          }
        }
      }
    }
  }
}
</style>
